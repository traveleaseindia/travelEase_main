
document.querySelector("form").addEventListener("submit", async function(event) {
    event.preventDefault();

    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    const response = await fetch("http://localhost:5000/signup", {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, email, password }),
    });

    const data = await response.json();
    alert(data.message);
});
//
function viewDetails(destination) {
    alert("Showing details for " + destination);
    // You can replace the alert with a page redirection if needed
    window.location.href = destination + "destinations.html";  // Redirects to destination-specific page
}

//
